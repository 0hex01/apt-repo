#!/usr/bin/env python3
"""
Armoury Crate - Linux RGB Control for ASUS ROG Laptops

USB behavior:
- Briefly detaches/claims HID interface 0 only while applying RGB settings
  (required; otherwise the kernel driver returns Resource busy).
- Reattaches the kernel driver afterward so keyboard input keeps working.
"""

import sys
import json
import os
import time

try:
    import usb.core
    import usb.util
    _USB_AVAILABLE = True
except ImportError:
    usb = None
    _USB_AVAILABLE = False

from PyQt6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QComboBox,
    QPushButton,
    QLabel,
    QSlider,
    QColorDialog,
    QGroupBox,
    QGridLayout,
    QSpinBox,
    QMessageBox,
    QFrame,
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor, QPalette


VENDOR_ID = 0x0B05
# Known ASUS ROG keyboard PIDs - 0x19B6 first (original target)
PRODUCT_IDS = [0x19B6, 0x1954, 0x1854, 0x1866, 0x1869, 0x1867, 0x18C6]
PRODUCT_ID = PRODUCT_IDS[0]


def errno_of(exc):
    """pyusb >=1.2 may lack .errno; fall back to backend_error_code."""
    err = getattr(exc, 'errno', None)
    if err is None:
        err = getattr(exc, 'backend_error_code', None)
    return err

MODES = {
    "Static": 0,
    "Breathing": 1,
    "Rainbow": 2,
    "Wave": 3,
    "Reactive": 4,
    "Star": 5,
    "Flash": 6,
}

CONFIG_FILE = os.path.expanduser("~/.config/armoury-crate/config.json")


class ROGKeyboard:
    """ASUS ROG keyboard RGB controller."""

    MESSAGE_LENGTH = 17
    SPEED_BYTE_VALUES = {1: 0xE1, 2: 0xEB, 3: 0xF5}
    RGB_INTERFACE = 0

    def __init__(self):
        self.device = None
        self._interface_claimed = False
        self._detached_kernel = False
        self._reconnect_attempts = 0
        self._max_reconnect_attempts = 3

    def connect(self):
        """Locate the N-KEY device. Interface claim happens only while applying."""
        if not _USB_AVAILABLE:
            print("Error: pyusb not installed (try: sudo apt install python3-usb)")
            return False
        try:
            self.device = None
            # Try each known ASUS ROG keyboard PID
            for pid in PRODUCT_IDS:
                self.device = usb.core.find(
                    idVendor=VENDOR_ID,
                    idProduct=pid,
                )
                if self.device is not None:
                    break

            if self.device is None:
                # Diagnostic: list all ASUS devices present
                asus_devs = list(usb.core.find(find_all=True, idVendor=VENDOR_ID))
                if asus_devs:
                    found = ", ".join(f"{d.idProduct:04x}" for d in asus_devs)
                    print(f"ASUS devices found (PIDs): {found}")
                    print("None matched known keyboard PIDs - add your PID to PRODUCT_IDS")
                raise RuntimeError(
                    f"ASUS ROG keyboard not found (VID {VENDOR_ID:04x})"
                )

            print(f"Found device: {self.device}")
            self._reconnect_attempts = 0
            return True

        except usb.core.USBError as exc:
            print(f"USB error connecting to keyboard: {errno_of(exc)} - {exc}")
            self.device = None
            return False
        except Exception as exc:
            print(f"Error connecting to keyboard: {exc}")
            self.device = None
            return False

    def _acquire_interface(self):
        """Detach kernel driver and claim interface 0 for RGB transfers."""
        if self.device is None and not self.connect():
            return False

        if self._interface_claimed:
            return True

        try:
            if self.device.is_kernel_driver_active(self.RGB_INTERFACE):
                self.device.detach_kernel_driver(self.RGB_INTERFACE)
                self._detached_kernel = True

            try:
                self.device.set_configuration()
            except usb.core.USBError as exc:
                if errno_of(exc) != 16:
                    raise

            usb.util.claim_interface(self.device, self.RGB_INTERFACE)
            self._interface_claimed = True
            return True

        except usb.core.USBError as exc:
            print(f"USB error claiming interface: {errno_of(exc)} - {exc}")
            self._release_interface()
            return False

    def _release_interface(self):
        """Release interface 0 and reattach the kernel HID driver."""
        if self.device is None:
            self._interface_claimed = False
            self._detached_kernel = False
            return

        if self._interface_claimed:
            try:
                usb.util.release_interface(self.device, self.RGB_INTERFACE)
            except Exception as exc:
                print(f"Warning: error releasing interface: {exc}")
            self._interface_claimed = False

        if self._detached_kernel:
            try:
                self.device.attach_kernel_driver(self.RGB_INTERFACE)
            except Exception as exc:
                print(f"Warning: error reattaching kernel driver: {exc}")
            self._detached_kernel = False

    def disconnect(self):
        """Release USB resources and restore the kernel HID driver."""
        self._release_interface()

        if self.device is not None:
            try:
                usb.util.dispose_resources(self.device)
            except Exception as exc:
                print(f"Warning: error disposing USB resources: {exc}")

        self.device = None

    def __enter__(self):
        if self.device is None:
            self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()
        return False

    def control_transfer(self, data, timeout=1000):
        """Send one HID class control transfer."""
        if self.device is None and not self.connect():
            print("Error: keyboard is not connected")
            return False

        if len(data) != self.MESSAGE_LENGTH:
            print(
                f"Warning: message length is {len(data)}, "
                f"expected {self.MESSAGE_LENGTH}"
            )

        try:
            result = self.device.ctrl_transfer(
                0x21,
                0x09,
                0x035D,
                0x0000,
                data,
                timeout=timeout,
            )

            if result != len(data):
                print(
                    f"Warning: transfer returned {result} bytes, "
                    f"expected {len(data)}"
                )

            self._reconnect_attempts = 0
            return True

        except usb.core.USBError as exc:
            print(f"USB control transfer error: {errno_of(exc)} - {exc}")

            if errno_of(exc) in (19, 110):
                self._reconnect_attempts += 1

                if self._reconnect_attempts <= self._max_reconnect_attempts:
                    self.disconnect()

                    if self.connect():
                        return self.control_transfer(data, timeout)

            return False

        except Exception as exc:
            print(f"Control transfer error: {exc}")
            return False

    def init_message(self):
        msg = [0x00] * self.MESSAGE_LENGTH
        msg[0] = 0x5D
        msg[1] = 0xB3
        return msg

    def initialize_keyboard(self):
        """
        Send the ASUS initialization packet.

        This packet is sent without detaching the kernel keyboard driver.
        """
        msg = [
            0x5A, 0x41, 0x53, 0x55, 0x53, 0x20, 0x54, 0x65, 0x63,
            0x68, 0x2E, 0x49, 0x6E, 0x63, 0x2E, 0x00, 0x00,
        ]
        return self.control_transfer(msg)

    def set_brightness(self, brightness):
        brightness = max(0, min(100, int(brightness)))
        brightness_level = round(brightness * 3 / 100)

        msg = [0x5A, 0xBA, 0xC5, 0xC4, brightness_level] + [0x00] * 12
        return self.control_transfer(msg)

    def set_lighting(
        self,
        mode,
        red,
        green,
        blue,
        brightness=100,
        speed=2,
    ):
        mode = max(0, min(6, int(mode)))
        red = max(0, min(255, int(red)))
        green = max(0, min(255, int(green)))
        blue = max(0, min(255, int(blue)))
        brightness = max(0, min(100, int(brightness)))
        speed = max(1, min(3, int(speed)))

        if self.device is None and not self.connect():
            return False

        if not self._acquire_interface():
            return False

        try:
            print(
                f"Setting lighting: mode={mode}, "
                f"RGB=({red},{green},{blue}), "
                f"brightness={brightness}, speed={speed}"
            )

            msg = self.init_message()

            if mode == 0:
                msg[4] = red
                msg[5] = green
                msg[6] = blue

            elif mode == 1:
                msg[3] = 1
                msg[4] = red
                msg[5] = green
                msg[6] = blue
                msg[7] = self.SPEED_BYTE_VALUES[speed]
                msg[9] = 1
                msg[10] = red
                msg[11] = green
                msg[12] = blue

            elif mode == 2:
                msg[3] = 2
                msg[4] = 0xFF
                msg[7] = self.SPEED_BYTE_VALUES[speed]

            elif mode == 3:
                msg[3] = 3
                msg[4] = 0xFF
                msg[7] = self.SPEED_BYTE_VALUES[speed]

            else:
                # Unsupported modes fall back to a static color instead of
                # sending an unknown packet that could upset the device.
                msg[3] = 0
                msg[4] = red
                msg[5] = green
                msg[6] = blue

            if not self.control_transfer(msg):
                return False

            time.sleep(0.05)

            set_msg = [0x5D, 0xB5] + [0x00] * 15
            if not self.control_transfer(set_msg):
                return False

            time.sleep(0.05)

            apply_msg = [0x5D, 0xB4] + [0x00] * 15
            if not self.control_transfer(apply_msg):
                return False

            time.sleep(0.05)

            if not self.set_brightness(brightness):
                print("Warning: lighting applied, but brightness failed")

            print("Lighting settings applied successfully")
            return True

        except usb.core.USBError as exc:
            print(f"USB error setting lighting: {errno_of(exc)} - {exc}")
            return False
        except Exception as exc:
            print(f"Error setting lighting: {exc}")
            return False
        finally:
            self._release_interface()


class ConfigManager:
    def __init__(self):
        self.config_dir = os.path.dirname(CONFIG_FILE)
        os.makedirs(self.config_dir, exist_ok=True)

    def save_config(self, config):
        with open(CONFIG_FILE, "w", encoding="utf-8") as config_file:
            json.dump(config, config_file, indent=4)

    def load_config(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as config_file:
                    loaded = json.load(config_file)

                defaults = self.get_default_config()
                defaults.update(loaded)
                return defaults

            except (OSError, json.JSONDecodeError) as exc:
                print(f"Warning: could not load configuration: {exc}")

        return self.get_default_config()

    @staticmethod
    def get_default_config():
        return {
            "mode": "Static",
            "red": 0,
            "green": 255,
            "blue": 255,
            "brightness": 100,
            "speed": 2,
        }


class ArmouryCrateGUI(QMainWindow):
    def __init__(self):
        super().__init__()

        self.keyboard = ROGKeyboard()
        self.config_manager = ConfigManager()
        self.config = self.config_manager.load_config()

        self.init_ui()
        self.apply_config()
        self.keyboard.connect()
        self.update_status()

    def init_ui(self):
        self.setWindowTitle("Armoury Crate - ASUS ROG RGB Control")
        self.setGeometry(100, 100, 500, 400)

        self.apply_dark_theme()

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QVBoxLayout()
        central_widget.setLayout(main_layout)

        self.status_label = QLabel()
        main_layout.addWidget(self.status_label)

        mode_group = QGroupBox("Lighting Mode")
        mode_layout = QHBoxLayout()

        self.mode_combo = QComboBox()
        self.mode_combo.addItems(MODES.keys())
        self.mode_combo.setCurrentText(self.config["mode"])
        self.mode_combo.currentTextChanged.connect(self.on_mode_changed)

        mode_layout.addWidget(self.mode_combo)
        mode_group.setLayout(mode_layout)
        main_layout.addWidget(mode_group)

        color_group = QGroupBox("Color")
        color_layout = QGridLayout()

        self.color_button = QPushButton("Select Color")
        self.color_button.clicked.connect(self.on_color_select)

        self.color_preview = QFrame()
        self.color_preview.setFixedSize(100, 50)

        color_layout.addWidget(self.color_button, 0, 0)
        color_layout.addWidget(self.color_preview, 0, 1)

        color_group.setLayout(color_layout)
        main_layout.addWidget(color_group)

        rgb_group = QGroupBox("RGB Values")
        rgb_layout = QGridLayout()

        self.red_slider = QSlider(Qt.Orientation.Horizontal)
        self.red_slider.setRange(0, 255)
        self.red_slider.valueChanged.connect(self.on_rgb_changed)
        self.red_label = QLabel()

        self.green_slider = QSlider(Qt.Orientation.Horizontal)
        self.green_slider.setRange(0, 255)
        self.green_slider.valueChanged.connect(self.on_rgb_changed)
        self.green_label = QLabel()

        self.blue_slider = QSlider(Qt.Orientation.Horizontal)
        self.blue_slider.setRange(0, 255)
        self.blue_slider.valueChanged.connect(self.on_rgb_changed)
        self.blue_label = QLabel()

        rgb_layout.addWidget(self.red_label, 0, 0)
        rgb_layout.addWidget(self.red_slider, 0, 1)
        rgb_layout.addWidget(self.green_label, 1, 0)
        rgb_layout.addWidget(self.green_slider, 1, 1)
        rgb_layout.addWidget(self.blue_label, 2, 0)
        rgb_layout.addWidget(self.blue_slider, 2, 1)

        rgb_group.setLayout(rgb_layout)
        main_layout.addWidget(rgb_group)

        brightness_group = QGroupBox("Brightness")
        brightness_layout = QHBoxLayout()

        self.brightness_slider = QSlider(Qt.Orientation.Horizontal)
        self.brightness_slider.setRange(0, 100)
        self.brightness_slider.valueChanged.connect(
            self.on_brightness_changed
        )

        self.brightness_label = QLabel()

        brightness_layout.addWidget(self.brightness_slider)
        brightness_layout.addWidget(self.brightness_label)

        brightness_group.setLayout(brightness_layout)
        main_layout.addWidget(brightness_group)

        speed_group = QGroupBox("Effect Speed")
        speed_layout = QHBoxLayout()

        self.speed_spin = QSpinBox()
        self.speed_spin.setRange(1, 3)
        self.speed_spin.valueChanged.connect(self.on_speed_changed)

        speed_layout.addWidget(QLabel("Speed (1-3):"))
        speed_layout.addWidget(self.speed_spin)

        speed_group.setLayout(speed_layout)
        main_layout.addWidget(speed_group)

        button_layout = QHBoxLayout()

        self.apply_button = QPushButton("Apply")
        self.apply_button.clicked.connect(self.apply_settings)
        self.apply_button.setStyleSheet(
            "background-color: #4CAF50; color: white; padding: 10px;"
        )

        self.save_button = QPushButton("Save & Apply")
        self.save_button.clicked.connect(self.save_and_apply)
        self.save_button.setStyleSheet(
            "background-color: #2196F3; color: white; padding: 10px;"
        )

        button_layout.addWidget(self.apply_button)
        button_layout.addWidget(self.save_button)

        main_layout.addLayout(button_layout)
        main_layout.addStretch()

    @staticmethod
    def apply_dark_theme():
        palette = QPalette()

        palette.setColor(
            QPalette.ColorRole.Window,
            QColor(53, 53, 53),
        )
        palette.setColor(
            QPalette.ColorRole.WindowText,
            Qt.GlobalColor.white,
        )
        palette.setColor(
            QPalette.ColorRole.Base,
            QColor(25, 25, 25),
        )
        palette.setColor(
            QPalette.ColorRole.AlternateBase,
            QColor(53, 53, 53),
        )
        palette.setColor(
            QPalette.ColorRole.ToolTipBase,
            Qt.GlobalColor.white,
        )
        palette.setColor(
            QPalette.ColorRole.ToolTipText,
            Qt.GlobalColor.white,
        )
        palette.setColor(
            QPalette.ColorRole.Text,
            Qt.GlobalColor.white,
        )
        palette.setColor(
            QPalette.ColorRole.Button,
            QColor(53, 53, 53),
        )
        palette.setColor(
            QPalette.ColorRole.ButtonText,
            Qt.GlobalColor.white,
        )
        palette.setColor(
            QPalette.ColorRole.BrightText,
            Qt.GlobalColor.red,
        )
        palette.setColor(
            QPalette.ColorRole.Link,
            QColor(42, 130, 218),
        )
        palette.setColor(
            QPalette.ColorRole.Highlight,
            QColor(42, 130, 218),
        )
        palette.setColor(
            QPalette.ColorRole.HighlightedText,
            Qt.GlobalColor.black,
        )

        QApplication.setPalette(palette)

    def update_status(self):
        if self.keyboard.device is not None:
            self.status_label.setText("✓ Keyboard Connected")
            self.status_label.setStyleSheet(
                "color: #4CAF50; font-weight: bold;"
            )
        else:
            self.status_label.setText("✗ Keyboard Not Connected")
            self.status_label.setStyleSheet(
                "color: #f44336; font-weight: bold;"
            )

    def on_mode_changed(self, mode):
        self.config["mode"] = mode

    def on_color_select(self):
        color = QColorDialog.getColor()

        if color.isValid():
            self.red_slider.setValue(color.red())
            self.green_slider.setValue(color.green())
            self.blue_slider.setValue(color.blue())

    def on_rgb_changed(self):
        self.config["red"] = self.red_slider.value()
        self.config["green"] = self.green_slider.value()
        self.config["blue"] = self.blue_slider.value()

        self.red_label.setText(f"R: {self.config['red']}")
        self.green_label.setText(f"G: {self.config['green']}")
        self.blue_label.setText(f"B: {self.config['blue']}")

        self.update_color_preview()

    def update_color_preview(self):
        self.color_preview.setStyleSheet(
            f"background-color: rgb("
            f"{self.config['red']}, "
            f"{self.config['green']}, "
            f"{self.config['blue']}); "
            f"border: 2px solid white;"
        )

    def on_brightness_changed(self):
        self.config["brightness"] = self.brightness_slider.value()
        self.brightness_label.setText(
            f"{self.config['brightness']}%"
        )

    def on_speed_changed(self):
        self.config["speed"] = self.speed_spin.value()

    def apply_settings(self):
        mode_name = self.config.get("mode", "Static")
        mode = MODES.get(mode_name, 0)

        success = self.keyboard.set_lighting(
            mode=mode,
            red=self.config["red"],
            green=self.config["green"],
            blue=self.config["blue"],
            brightness=self.config["brightness"],
            speed=self.config["speed"],
        )

        self.update_status()

        if success:
            QMessageBox.information(
                self,
                "Success",
                "Lighting settings applied.",
            )
        else:
            QMessageBox.warning(
                self,
                "Error",
                "Failed to apply lighting settings.\n\n"
                "Check USB permissions for the ASUS N-KEY device "
                "(udev rule / plugdev access).",
            )

    def save_and_apply(self):
        try:
            self.config_manager.save_config(self.config)
        except OSError as exc:
            QMessageBox.warning(
                self,
                "Configuration Error",
                f"Could not save configuration:\n{exc}",
            )
            return

        self.apply_settings()

    def apply_config(self):
        mode = self.config.get("mode", "Static")
        if mode not in MODES:
            mode = "Static"
            self.config["mode"] = mode

        self.mode_combo.setCurrentText(mode)
        self.red_slider.setValue(
            max(0, min(255, int(self.config.get("red", 0))))
        )
        self.green_slider.setValue(
            max(0, min(255, int(self.config.get("green", 255))))
        )
        self.blue_slider.setValue(
            max(0, min(255, int(self.config.get("blue", 255))))
        )
        self.brightness_slider.setValue(
            max(0, min(100, int(self.config.get("brightness", 100))))
        )
        self.speed_spin.setValue(
            max(1, min(3, int(self.config.get("speed", 2))))
        )

        self.on_rgb_changed()
        self.on_brightness_changed()
        self.on_speed_changed()
        self.update_color_preview()

    def closeEvent(self, event):
        self.keyboard.disconnect()
        event.accept()


def main():
    app = QApplication(sys.argv)
    window = ArmouryCrateGUI()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
