#!/bin/bash
# ctrlaltdel disable - restore the Ctrl+Alt+Delete binding saved by enable.sh
# (defaults to xflock4 if no saved binding exists)

PROP="/commands/custom/<Primary><Alt>Delete"
STATE_FILE="${XDG_CACHE_HOME:-$HOME/.cache}/ctrlaltdel/previous-binding"

PREV=$(cat "$STATE_FILE" 2>/dev/null)
PREV="${PREV:-xflock4}"

xfconf-query -c xfce4-keyboard-shortcuts -p "$PROP" -s "$PREV" 2>/dev/null \
    || xfconf-query -c xfce4-keyboard-shortcuts -p "$PROP" -n -t string -s "$PREV"

echo "Ctrl+Alt+Delete restored to $PREV"
