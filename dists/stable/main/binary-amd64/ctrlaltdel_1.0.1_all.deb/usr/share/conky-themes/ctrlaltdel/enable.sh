#!/bin/bash
# ctrlaltdel enable - bind Ctrl+Alt+Delete to the XFCE session logout dialog
# (restart, shutdown, logout, suspend buttons). Saves the previous binding
# so `stop ctrlaltdel` can restore it.

PROP="/commands/custom/<Primary><Alt>Delete"
STATE_DIR="${XDG_CACHE_HOME:-$HOME/.cache}/ctrlaltdel"
STATE_FILE="$STATE_DIR/previous-binding"

mkdir -p "$STATE_DIR"

CURRENT=$(xfconf-query -c xfce4-keyboard-shortcuts -p "$PROP" 2>/dev/null)
if [ "$CURRENT" != "xfce4-session-logout" ]; then
    echo "${CURRENT:-xflock4}" > "$STATE_FILE"
fi

xfconf-query -c xfce4-keyboard-shortcuts -p "$PROP" -s "xfce4-session-logout" 2>/dev/null \
    || xfconf-query -c xfce4-keyboard-shortcuts -p "$PROP" -n -t string -s "xfce4-session-logout"

echo "Ctrl+Alt+Delete -> session menu enabled (was: ${CURRENT:-none})"
