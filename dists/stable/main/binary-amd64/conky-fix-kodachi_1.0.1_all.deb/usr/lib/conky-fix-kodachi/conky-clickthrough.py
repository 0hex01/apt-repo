#!/usr/bin/env python3
"""
conky-clickthrough - make all Conky windows click-transparent.

Sets an empty input region on every window whose WM_CLASS is 'Conky',
so mouse clicks fall through to whatever is underneath (desktop icons).

Runs in a loop so windows restarted by the conky watchdog/launcher
get re-fixed automatically.

Requires: python3-xlib, xdotool
"""

import subprocess
import time
from Xlib import display, X
from Xlib.ext import shape

POLL_INTERVAL = 5  # seconds


def empty_input_region(win):
    """Set the window's input shape to empty -> clicks pass through."""
    try:
        win.shape_rectangles(
            shape.SO.Set,      # operation: replace
            shape.SK.Input,    # target: input region
            X.Unsorted,        # ordering
            0, 0,              # offsets
            [],                # empty rect list = empty input region
        )
    except Exception as e:
        print(f'Failed to clear input region: {e}', flush=True)


def find_conky_window_ids():
    """Return IDs of all Conky windows.

    Uses xdotool search, which walks the whole window tree including
    clients reparented into WM frames (query_tree().children misses
    those).
    """
    try:
        out = subprocess.check_output(
            ['xdotool', 'search', '--class', 'conky'], timeout=5
        )
    except Exception:
        return []
    return [int(wid) for wid in out.split()]


def main():
    d = display.Display()
    while True:
        for wid in find_conky_window_ids():
            empty_input_region(d.create_resource_object('window', wid))
        d.sync()
        time.sleep(POLL_INTERVAL)


if __name__ == '__main__':
    main()
