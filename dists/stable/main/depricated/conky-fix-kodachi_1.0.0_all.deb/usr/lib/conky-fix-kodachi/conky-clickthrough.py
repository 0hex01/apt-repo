#!/usr/bin/env python3
"""
conky-clickthrough - make all Conky windows click-transparent.

Sets an empty input region on every window whose WM_CLASS is 'Conky',
so mouse clicks fall through to whatever is underneath (desktop icons).

Runs in a loop so windows restarted by the conky watchdog/launcher
get re-fixed automatically.

Requires: python3-xlib, xdotool
"""

import time
from Xlib import display, X
from Xlib.ext import shape

POLL_INTERVAL = 5  # seconds


def empty_input_region(win):
    """Set the window's input shape to empty -> clicks pass through."""
    try:
        win.shape_rectangles(
            shape.SO.Set,      # operation: replace
            shape.SK.Input,    # target: input region
            X.Unsorted,        # ordering
            0, 0,              # offsets
            [],                # empty rect list = empty input region
        )
    except Exception as e:
        print(f'Failed to clear input region: {e}', flush=True)


def find_conky_windows(root):
    """Yield all windows on the screen whose class is Conky."""
    try:
        children = root.query_tree().children
    except Exception:
        return
    for win in children:
        try:
            wm_class = win.get_wm_class()
        except Exception:
            wm_class = None
        if wm_class and wm_class[0].lower() == 'conky':
            yield win


def main():
    d = display.Display()
    root = d.screen().root
    while True:
        for win in find_conky_windows(root):
            empty_input_region(win)
        d.sync()
        time.sleep(POLL_INTERVAL)


if __name__ == '__main__':
    main()
